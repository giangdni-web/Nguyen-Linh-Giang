# Tạo APK Debug cho MrGiangAPP

Repository đã được bổ sung GitHub Actions tại `.github/workflows/build-debug-apk.yml`.

## Cách chạy

1. Giải nén gói ZIP này.
2. Mở repository GitHub `giangdni-web/Nguyen-Linh-Giang`.
3. Chọn **Add file → Upload files**.
4. Tải lên toàn bộ nội dung bên trong thư mục `Nguyen-Linh-Giang-main` (bao gồm thư mục ẩn `.github`). Nếu GitHub không hiển thị thư mục ẩn, hãy tải riêng `.github/workflows/build-debug-apk.yml` lên đúng đường dẫn đó.
5. Commit lên nhánh `main`.
6. Mở tab **Actions** → **Build MrGiangAPP Debug APK** → **Run workflow**.
7. Khi workflow chạy thành công, mở lần chạy mới nhất, kéo xuống **Artifacts** và tải `MrGiangAPP-debug-apk`.
8. Giải nén artifact để lấy file APK, sau đó mở APK trên điện thoại Android và cho phép cài ứng dụng từ nguồn này nếu Android hỏi.

## Ghi chú

- Workflow biên dịch biến thể `debug`, tạo khóa debug tạm thời trong mỗi lần chạy và tải APK lên dưới dạng GitHub Actions Artifact.
- Artifact được lưu 14 ngày.
- Đây là bản thử nghiệm/debug, không phải bản phát hành Play Store.
- Mã nguồn không có `google-services.json`; cấu hình Firebase được đặt ở chế độ cảnh báo khi thiếu. APK có thể biên dịch nhưng các tính năng Firebase có thể cần cấu hình Firebase đúng để hoạt động.
- Workflow cần được đưa lên GitHub và chạy trong GitHub Actions. Không thể lấy APK chỉ từ ZIP nguồn nếu chưa thực hiện bước biên dịch.
